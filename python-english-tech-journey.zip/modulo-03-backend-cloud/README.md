# Módulo 3 — Backend e Cloud

Semanas 9–12: HTTP, APIs, FastAPI, SQLite, testes e AWS. Ainda não iniciado.
