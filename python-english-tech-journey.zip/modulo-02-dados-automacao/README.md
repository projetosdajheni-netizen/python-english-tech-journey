# Módulo 2 — Dados e automação

Semanas 5–8: listas, CSV, SQL, Pandas e automação. Ainda não iniciado.
