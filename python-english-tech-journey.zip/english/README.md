# English Tech

Vocabulário inicial: variable, string, print, integer, float, salary, bonus. Próxima aula: apresentação pessoal em inglês. Ainda não realizada.
