"""Aula 2: calculadora de remuneração concluída em 23/11/2026."""
salario_base = 2600
bonus = 200
desconto = 150
salario_final = salario_base + bonus - desconto
print(salario_final)  # 2650
