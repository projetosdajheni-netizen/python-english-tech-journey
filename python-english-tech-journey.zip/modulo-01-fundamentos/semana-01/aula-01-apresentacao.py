"""Aula 1: programa de apresentação concluído em 23/11/2026."""
nome = "Jhenifer"
area = "Tecnologia"
objetivo = "Migrar para a área Tech"

print("ola meu nome é", nome)
print(" Estou estudando", area)
print("Minha jornada em Python começou!")
print("Meu objetivo é", objetivo)
