# Módulo 1 — Fundamentos

Semanas 1–4: Python básico, lógica e inglês inicial. Exercícios da primeira semana em `semana-01/`.
