# Python + English Tech Journey 🚀

**16 semanas · 6 horas/semana · 96 horas · Início: 23/11/2026**

Trilha de formação prática em Python, inglês técnico, análise de dados, Backend e Cloud, com foco em transição profissional e aplicações para o mercado financeiro.

**EN:** A 16-week learning journey connecting Python, technical English, data analytics, backend and cloud skills with practical business problems.

## Formação / Learning path

| Módulo | Semanas | Entrega |
|---|---|---|
| Fundamentos | 1–4 | Primeiro programa e quiz |
| Dados e automação | 5–8 | Análise de transações fictícias |
| Backend e Cloud | 9–12 | API documentada |
| Projeto e empregabilidade | 13–16 | Fraud Analytics Lab e pitch bilíngue |

- [Cronograma detalhado](ROADMAP.md)
- [Diário de progresso](PROGRESS.md)
- [Projeto final](fraud-analytics-lab/README.md)

## Semana 1
- [x] Aula 1 — variáveis, strings e print()
- [x] Aula 2 — números, operações e snake_case
- [ ] Inglês — apresentação pessoal

Todos os dados usados nos projetos de fraude serão fictícios ou públicos permitidos. Não serão publicados dados reais de clientes ou empregadores.
