# Fraud Analytics Lab

**Projeto final planejado (não iniciado).** Análise de dados sintéticos de transações, detecção de comportamentos atípicos por regras documentadas e apresentação de resultados com Python e SQL/Pandas; API se viável. Sem dados reais de clientes.
