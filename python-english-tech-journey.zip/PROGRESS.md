# Diário de aprendizagem

## Semana 1 — 23 a 29/11/2026

- [x] **Aula 1:** variáveis, strings, print(). Primeiro NameError corrigido; programa exibiu apresentação, área e objetivo.
- [x] **Aula 2:** calculadora com salário-base 2600, bônus 200, desconto 150, resultado 2650. Aprendizado sobre snake_case. Houve ajuda do Gemini na correção de sintaxe, seguida de exercício independente de correção.
- [ ] **Inglês:** apresentação pessoal ainda não realizada.
- [ ] **Retrospectiva:** pendente.

As atividades futuras não serão marcadas como concluídas antes de serem realizadas e verificadas.
