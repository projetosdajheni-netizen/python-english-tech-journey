# Módulo 4 — Projeto e empregabilidade

Semanas 13–16: MVP, portfólio, entrevistas e Demo Day. Ainda não iniciado.
