# Demo Day

Pitch bilíngue planejado para a semana 16: problema, público, solução, demonstração, resultados e próximos passos. Ainda não iniciado.
