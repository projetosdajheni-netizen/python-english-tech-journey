# Cronograma — Python + Inglês Tech

16 semanas, 6 horas semanais (3h Python, 2h inglês, 1h projeto), início em 23/11/2026.

## Módulo 1: Fundamentos

### Semana 1 — 23/11/2026 a 29/11/2026
- Python: Variáveis, strings, print; tipos numéricos e operações.
- Inglês: Apresentação pessoal e termos técnicos.
- Entrega: Programa de apresentação e calculadora.

### Semana 2 — 30/11/2026 a 06/12/2026
- Python: Operadores, input e conversão de tipos.
- Inglês: Números e profissões.
- Entrega: Calculadora interativa.

### Semana 3 — 07/12/2026 a 13/12/2026
- Python: Condicionais if/elif/else.
- Inglês: Perguntas e respostas simples.
- Entrega: Regras de negócio.

### Semana 4 — 14/12/2026 a 20/12/2026
- Python: Laços e funções.
- Inglês: Explicar funcionamento de um programa.
- Entrega: Desafio 1: quiz.

## Módulo 2: Dados e automação

### Semana 5 — 21/12/2026 a 27/12/2026
- Python: Listas, dicionários e dados tabulares.
- Inglês: Vocabulário de transações.
- Entrega: Transações sintéticas.

### Semana 6 — 28/12/2026 a 03/01/2027
- Python: CSV, funções e automação.
- Inglês: Descrever processos.
- Entrega: Importação e limpeza.

### Semana 7 — 04/01/2027 a 10/01/2027
- Python: SQL e consultas básicas.
- Inglês: Tabelas e consultas.
- Entrega: Consultas fictícias.

### Semana 8 — 11/01/2027 a 17/01/2027
- Python: Pandas, agrupamentos e gráficos.
- Inglês: Explicar indicadores.
- Entrega: Desafio 2: análise de transações.

## Módulo 3: Backend e Cloud

### Semana 9 — 18/01/2027 a 24/01/2027
- Python: HTTP, JSON e APIs.
- Inglês: Requests e respostas.
- Entrega: Consumo de API pública.

### Semana 10 — 25/01/2027 a 31/01/2027
- Python: FastAPI, rotas e parâmetros.
- Inglês: Descrever endpoints.
- Entrega: API local simples.

### Semana 11 — 01/02/2027 a 07/02/2027
- Python: SQLite e organização de projetos.
- Inglês: Documentação de funcionalidades.
- Entrega: API com persistência.

### Semana 12 — 08/02/2027 a 14/02/2027
- Python: Testes básicos, segurança e AWS.
- Inglês: Leitura de documentação.
- Entrega: Desafio 3: mini API.

## Módulo 4: Projeto e empregabilidade

### Semana 13 — 15/02/2027 a 21/02/2027
- Python: Definir problema, público e MVP.
- Inglês: Problem / solution / audience.
- Entrega: Escopo do Fraud Analytics Lab.

### Semana 14 — 22/02/2027 a 28/02/2027
- Python: Construir MVP, indicadores e análise.
- Inglês: Explicar fluxo.
- Entrega: MVP funcional.

### Semana 15 — 01/03/2027 a 07/03/2027
- Python: Testes, portfólio, vagas e entrevistas.
- Inglês: Ensaiar apresentação.
- Entrega: Slides e projeto revisado.

### Semana 16 — 08/03/2027 a 14/03/2027
- Python: Demo Day, currículo e retrospectiva.
- Inglês: Pitch bilíngue.
- Entrega: Apresentação final.

## Avaliação
- Código funcional: 40%
- Conceitos técnicos: 25%
- Inglês: 20%
- Documentação e comunicação: 15%

## Pitch final (5 minutos)
- 0:00–0:30 apresentação pessoal em inglês
- 0:30–1:15 problema e público
- 1:15–2:00 solução e tecnologias
- 2:00–3:30 demonstração
- 3:30–4:15 resultados
- 4:15–5:00 próximos passos e encerramento bilíngue
